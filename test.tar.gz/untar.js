const tar = require('tar');
const axios = require('axios');

const url = process.argv.slice(2)[0]
function entryHandler(entry) {
  console.log(entry.path)
}
axios.get(url)
  .then(function (response){
    tar.x({
      C: './tmp',
      onentry: entryHandler
    }).write(response);
  })
  .catch(function (error){
    console.log(error);
  });

